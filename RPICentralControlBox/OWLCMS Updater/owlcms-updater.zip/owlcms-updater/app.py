from flask import Flask, request, render_template
import os
import subprocess
import shutil

UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files.get('file')
    if not file:
        return "No file uploaded", 400

    filename = file.filename.lower()
    if not filename.endswith('.deb'):
        return "Invalid file. Please upload a valid OWLCMS .deb package.", 400

    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(save_path)

    # Install the .deb package using dpkg
    try:
        result = subprocess.run(
            ['sudo', 'dpkg', '-i', save_path],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            return f"Failed to install package:\n{result.stderr}", 500

        # Optional: Restart OWLCMS service if installed as a systemd service
        subprocess.run(['sudo', 'systemctl', 'restart', 'owlcms'], check=False)

        return "OWLCMS .deb installed and service restarted successfully!"

    except Exception as e:
        return f"Error: {str(e)}", 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
